#!/usr/bin/env python3
import argparse, sys, time, json, hashlib, multiprocessing as mp
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import independent_scaled_fast as v

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'certificate' / 'global-certificate-original.json'
IMPROVED = ROOT / 'certificate' / 'improved-global-certificate.json'
REWEIGHT = ROOT / 'evidence' / 'reweighted_fullscan_receipt.json'
TARGET = 1000047559

def worker(r):
    return r, v.row_min_fast(r)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--jobs', type=int, default=5)
    ap.add_argument('--output', type=Path, default=ROOT/'evidence'/'recomputed-independent-full-replay.json')
    args=ap.parse_args()
    v.sweep_numba(1,v.np.array([0,0],dtype=v.np.int64),v.np.array([],dtype=v.np.int64),v.np.array([],dtype=v.np.int64),v.np.array([],dtype=v.np.int64),v.np.array([0],dtype=v.np.int64),v.np.array([1],dtype=v.np.int64))
    source_sha=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    improved_sha=hashlib.sha256(IMPROVED.read_bytes()).hexdigest()
    start=time.time(); vals=[]; bad=[]; mn=10**30; mx=-1
    with mp.get_context('fork').Pool(args.jobs) as p:
        for k,(r,z) in enumerate(p.imap_unordered(worker, range(12028), chunksize=1),1):
            vals.append((r,z)); mn=min(mn,z); mx=max(mx,z)
            if z!=TARGET: bad.append((r,z))
            if k%250==0 or k==12028:
                print(f'INDEPENDENT {k}/12028 min={mn} max={mx} bad={len(bad)} elapsed={time.time()-start:.1f}s', flush=True)
    vals.sort(); hist={}
    for _,z in vals: hist[str(z)]=hist.get(str(z),0)+1
    rec0=json.load(open(REWEIGHT)); budget=v.budget
    result={
      'status':'PASS_INDEPENDENT_FULL_REPLAY' if not bad and mn==TARGET and mx==TARGET else 'FAIL',
      'implementation':'portable Fraction/integer geometry + integer cross-product legal-cell tests + Numba block sweep; independent of the Kleddamag primary Python sweep',
      'source_sha256':source_sha,
      'improved_certificate_sha256':improved_sha,
      'lambda':'999999999/1000000000',
      'row_range':[0,12027], 'row_count':len(vals),
      'minimum_units':mn, 'maximum_units':mx, 'target_units':TARGET,
      'bad_count':len(bad), 'bad_rows':bad[:100], 'histogram':hist,
      'budget_units':budget, 'counting_surplus_units':11*mn-budget,
      'bound_exact':'3875000000/999999999', 'elapsed_seconds':time.time()-start,
      'crosscheck_fixed_parameter_receipt_minimum':rec0['certified_minimum_units'],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
    if result['status']!='PASS_INDEPENDENT_FULL_REPLAY': raise SystemExit(1)
if __name__=='__main__': main()
