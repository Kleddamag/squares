# Zenodo metadata for this release

Use the following metadata when creating the Zenodo record manually.

## Basic information

- **Digital Object Identifier:** Reserved Zenodo DOI: `10.5281/zenodo.23038546`. Keep this draft and publish this same Zenodo record so the reserved DOI is registered to the final release.
- **Resource type:** Publication -> Preprint
- **Title:** An Exact Computer-Assisted Improvement of the Lower Bound for Packing Eleven Unit Squares
- **Publication date:** 2026-09-29 (use this only if this is the first date the release is made public; otherwise use the actual first-public date)
- **Publisher:** Zenodo
- **Version:** 1.0.0
- **Language:** English
- **Files visibility:** Public

## Creators

Creator order: Wang Ke first, Li Can second.

1. **Family name:** Wang  
   **Given names:** Ke  
   **Chinese name:** 王可  
   **Affiliation:** Fudan University  
   **ROR:** https://ror.org/013q1eq08

2. **Family name:** Li  
   **Given names:** Can  
   **Chinese name:** 李灿  
   **Affiliation:** Fudan University  
   **ROR:** https://ror.org/013q1eq08

In the Zenodo creator form, select the auto-completed **Fudan University** affiliation from ROR rather than adding it only as free text. Add ORCID identifiers only if the authors actually have and wish to use them; do not invent identifiers.

## Description / abstract

We give an exact computer-assisted certificate implying

`s(11) > 3875000000/999999999 = 3.875000003875000003875...`

for packing eleven independently rotatable unit squares into a square. The certificate is obtained by reweighting thirteen threshold-charge orbits in the public `s(11) > 31/8` certificate and then applying the common exact rational scaling factor `999999999/1000000000` to the parent and strict-core side parameters. The accompanying reproducibility package contains the frozen source and improved certificates, exact replay receipts, two separately implemented exact verifiers, integrity hashes, source attribution, and the preprint in PDF, DOCX, and LaTeX formats.

The exact improvement over `31/8` is

`31/7999999992 > 0`.

During final packaging, a fresh primary exact replay covered all 12,028 angular rows, with histogram `{1000047559: 12028}` and zero bad rows. An earlier complete independent-verifier replay is also preserved in the archive.

A dated public literature/registry check on 29 September 2026 located no registered strict lower bound at this value or a larger value. The record states this dated search result without making a separate priority claim.

## Keywords

- square packing
- unit squares
- packing problem
- discrete geometry
- computational geometry
- computer-assisted proof
- exact verification
- reproducible research
- s(11)

## Related works

Add these in Zenodo's **Related works** section:

1. **Identifier:** https://github.com/Kleddamag/11-squares-certified-bound  
   **Relation:** Is derived from  
   **Reason:** direct source certificate and derived verifier lineage.

2. **Identifier:** https://github.com/jlevy/squares  
   **Relation:** References  
   **Reason:** upstream Squares Project threshold-certificate framework/data lineage.

Do not add Kleddamag, Joshua Levy, or Squares Project contributors as creators or coauthors of this record; their work is credited through the paper, source-attribution files, third-party notices, and related-work links.

## Licenses

Zenodo supports mixed-license uploads. Add **both** licences to the record:

1. **Creative Commons Attribution 4.0 International (CC-BY-4.0)**
2. **MIT License (MIT)**

The archive itself defines the file-level scope in `LICENSE_STATUS.md`:

- Wang Ke / Li Can paper, original documentation, metadata, and research-record material: **CC BY 4.0**;
- Wang Ke / Li Can original verifier code: **MIT**;
- Kleddamag-derived verifier code: upstream **MIT** notice retained;
- upstream-derived certificate/data material: attribution and modification notices retained as described in `THIRD_PARTY_NOTICES.md`.

Do not describe either licence as applying indiscriminately to every file in the archive.

## Optional fields

- **Contributors:** leave blank unless there is a real non-author contributor whom you intend to credit.
- **Funding:** leave blank unless this work was actually supported by a grant/funder that should be disclosed.
- **Communities:** optional; none is required for publication.

## File upload

Upload the complete release archive. It contains the paper, certificates, verifiers, receipts, manifest, hashes, attribution notices, and citation metadata.
