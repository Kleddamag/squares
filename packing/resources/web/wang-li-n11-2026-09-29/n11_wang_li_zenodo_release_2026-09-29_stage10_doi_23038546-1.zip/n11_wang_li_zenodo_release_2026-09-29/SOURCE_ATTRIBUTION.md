# Sources and attribution

This research release is a derivative continuation of **Kleddamag**, *Eleven unit squares: a certified lower bound* (September 2026):

- https://github.com/Kleddamag/11-squares-certified-bound
- source theorem: `s(11) > 31/8`
- frozen source certificate SHA-256: `57e9927da5c13f42dd8bcbf8f08c84363635fece626657ee63a810c61cd44458`
- Kleddamag's repository states that its result was developed from the Squares Project T-026 threshold certificate.

Kleddamag's source certificate in turn derives from **Joshua Levy and collaborators, The Squares Project**:

- https://github.com/jlevy/squares
- the Kleddamag attribution record identifies the T-026 source revision as `7ccb679cc0827d10ee80e2cd1988c8a07d65dfdc`.

The present continuation changes thirteen threshold-charge orbit weights and then multiplies the parent side `A` and every row-specific core side `B` by

`999999999 / 1000000000`.

The full 12,028-row certificate is then replayed exactly at the derived parameters.

## What is new in this release

- 13-orbit nonnegative reweighting;
- exact common rational shrink of `A` and all row-specific `B` values;
- frozen derived certificate with SHA-256 `31e10ceb8368cc858e61f45ce7cfee783e8d0c7910893559164810f45439cc34`;
- full-replay evidence at the improved ratio;
- portable release-level integrity and replay entry point.

Source credit does not imply endorsement or coauthorship by Kleddamag, Joshua Levy, the Squares Project contributors, or Walter Trump.
