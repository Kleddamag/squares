import json, os, sys, time, math, multiprocessing as mp
from pathlib import Path
from fractions import Fraction as Q
import numpy as np
from numba import njit
import independent_core as ia
ROOT = Path(__file__).resolve().parents[2]
base=json.load(open(ROOT/'certificate'/'global-certificate-original.json'))
rec=json.load(open(ROOT/'evidence'/'reweighted_fullscan_receipt.json'))
mod=ia.apply_deltas(base,rec)
lam=Q(999999999,1000000000)
def fs(x): return str(x.numerator) if x.denominator==1 else f'{x.numerator}/{x.denominator}'
mod['A']=fs(Q(base['A'])*lam)
for row in mod['entries']: row[3]=fs(Q(row[3])*lam)
pts,pw,signed,budget,D=ia.expand_positive_and_signed(mod)
TARGET=1000047559

@njit(cache=True, nogil=True)
def sweep_numba(nleaves, offsets, yl, yh, ww, legal_lo, legal_hi):
    BS=128
    nb=(nleaves+BS-1)//BS
    vals=np.zeros(nleaves,dtype=np.int64)
    lazy=np.zeros(nb,dtype=np.int64)
    bmin=np.zeros(nb,dtype=np.int64)
    best=np.int64(10**18)

    for k in range(len(legal_lo)):
        for e in range(offsets[k], offsets[k+1]):
            l=yl[e]; r=yh[e]; v=ww[e]
            if l>=r: continue
            bl=l//BS; br=(r-1)//BS
            if bl==br:
                for i in range(l,r): vals[i]+=v
                st=bl*BS; en=min(st+BS,nleaves); m=vals[st]
                for i in range(st+1,en):
                    if vals[i]<m: m=vals[i]
                bmin[bl]=m
            else:
                en=(bl+1)*BS
                for i in range(l,en): vals[i]+=v
                st=bl*BS; m=vals[st]
                for i in range(st+1,en):
                    if vals[i]<m: m=vals[i]
                bmin[bl]=m
                st=br*BS
                for i in range(st,r): vals[i]+=v
                en=min(st+BS,nleaves); m=vals[st]
                for i in range(st+1,en):
                    if vals[i]<m: m=vals[i]
                bmin[br]=m
                for b in range(bl+1,br): lazy[b]+=v

        l=legal_lo[k]
        if l>=0:
            r=legal_hi[k]
            bl=l//BS; br=(r-1)//BS
            z=np.int64(10**18)
            if bl==br:
                la=lazy[bl]
                for i in range(l,r):
                    q=vals[i]+la
                    if q<z: z=q
            else:
                la=lazy[bl]; en=(bl+1)*BS
                for i in range(l,en):
                    q=vals[i]+la
                    if q<z: z=q
                la=lazy[br]; st=br*BS
                for i in range(st,r):
                    q=vals[i]+la
                    if q<z: z=q
                for b in range(bl+1,br):
                    q=bmin[b]+lazy[b]
                    if q<z: z=q
            if z<best: best=z
    return int(best)


def legal_y_indices_int(aa,bb,ye,edges):
    # Exact rational arithmetic via integer cross-products; no Fraction objects.
    vals=[]
    for x1,x2,m,n,d in edges:
        if x1<=aa and bb<=x2:
            vals.append((m*aa+n,d)); vals.append((m*bb+n,d))
    if len(vals)!=4: return None
    lo_num,lo_den=vals[0]; hi_num,hi_den=vals[0]
    for num,den in vals[1:]:
        if num*lo_den < lo_num*den:
            lo_num,lo_den=num,den
        if num*hi_den > hi_num*den:
            hi_num,hi_den=num,den
    # bisect_right(ye, low)-1
    l=0; r=len(ye)
    while l<r:
        m=(l+r)//2
        if ye[m]*lo_den <= lo_num: l=m+1
        else: r=m
    ilo=l-1
    # bisect_left(ye, high)
    l=0; r=len(ye)
    while l<r:
        m=(l+r)//2
        if ye[m]*hi_den < hi_num: l=m+1
        else: r=m
    ihi=l
    if ilo<0: ilo=0
    if ihi>len(ye)-1: ihi=len(ye)-1
    return (ilo,ihi) if ilo<ihi else None

def row_min_fast(ri):
    uv,half,poly,xe,ye,events,edges,scale,C,S,R=ia.build_row(mod,pts,pw,signed,D,ri)
    # flatten events
    offsets=[0]; yl=[]; yh=[]; ww=[]
    legal_lo=[]; legal_hi=[]
    for k in range(len(xe)-1):
        for a,b,w in events[k]:
            yl.append(a); yh.append(b); ww.append(w)
        offsets.append(len(yl))
        rg=legal_y_indices_int(xe[k],xe[k+1],ye,edges)
        if rg is None: legal_lo.append(-1); legal_hi.append(-1)
        else: legal_lo.append(rg[0]); legal_hi.append(rg[1])
    # events at final xe are irrelevant to open slabs; offsets length == len(xe)
    return sweep_numba(len(ye)-1,
        np.asarray(offsets,dtype=np.int64),np.asarray(yl,dtype=np.int64),np.asarray(yh,dtype=np.int64),np.asarray(ww,dtype=np.int64),
        np.asarray(legal_lo,dtype=np.int64),np.asarray(legal_hi,dtype=np.int64))

def f(r):
    return r,row_min_fast(r)

if __name__=='__main__':
    # compile before fork
    _=sweep_numba(1,np.array([0,0],dtype=np.int64),np.array([],dtype=np.int64),np.array([],dtype=np.int64),np.array([],dtype=np.int64),np.array([0],dtype=np.int64),np.array([1],dtype=np.int64))
    lo=int(os.environ.get('LO','0')); hi=int(os.environ.get('HI','12027')); n=int(os.environ.get('NPROC','16')); t=time.time(); vals=[]
    with mp.get_context('fork').Pool(n) as p:
        for x in p.imap_unordered(f,range(lo,hi+1),chunksize=1): vals.append(x)
    vals.sort(); vs=[v for _,v in vals]
    print('range',lo,hi,'count',len(vals),'min',min(vs),'max',max(vs),'bad',sum(v!=TARGET for v in vs),'elapsed',round(time.time()-t,2))
