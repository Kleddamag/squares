# Fresh primary full exact replay

- Scope: **all rows 0–12027**.
- Rows checked: **12028 / 12028**.
- Certificate SHA-256: `31e10ceb8368cc858e61f45ce7cfee783e8d0c7910893559164810f45439cc34`.
- Result: **PASS**.
- Minimum row charge: **1000047559**.
- Maximum row charge: **1000047559**.
- Histogram: `{1000047559: 12028}`.
- Counting surplus: **428125** units.
- Quarter coverage: `0–3006`, `3007–6013`, `6014–9020`, `9021–12027`.

The four quarter receipts cover every angular row exactly once, with no gaps or overlaps.
