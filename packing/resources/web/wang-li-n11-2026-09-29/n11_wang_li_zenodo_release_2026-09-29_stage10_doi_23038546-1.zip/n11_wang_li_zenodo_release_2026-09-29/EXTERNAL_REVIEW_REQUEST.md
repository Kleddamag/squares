# External verification request

We are releasing an exact computer-assisted lower-bound certificate for packing eleven unit squares:

` s(11) > 3875000000 / 999999999 = 3.875000003875000003875... `

Zenodo DOI: `10.5281/zenodo.23038546`

The construction is a derivative continuation of Kleddamag's September 2026 `s(11) > 31/8` certificate. Relative to the frozen source certificate, we:

1. increase exactly 13 threshold-charge orbit weights;
2. obtain a fixed-parameter minimum charge of `1000047559` on every one of the 12,028 angle rows;
3. multiply the parent side `A` and every row-specific core side `B` by the exact common factor `999999999/1000000000`;
4. replay the full 12,028-row catalogue exactly at the derived parameters.

Frozen derived certificate SHA-256:

`31e10ceb8368cc858e61f45ce7cfee783e8d0c7910893559164810f45439cc34`

Recorded complete replays both return the one-bin histogram:

`{1000047559: 12028}`

with budget `11000095024` and counting surplus `428125` in units of `10^-9`.

For a fresh local check:

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python verify.py --mode quick
python verify.py --mode full --jobs 5
```

We would especially value independent confirmation of: (i) the parent/core scaling argument, (ii) the 13-orbit reweighting and budget recomputation, and (iii) a fresh all-row replay from the frozen certificate.

We welcome an independent replay of the complete certificate and any additional literature check of the dated public-record statement in the paper.

Authors: **Wang Ke and Li Can, Fudan University**.
