# Wang–Li `s(11)` exact lower-bound release

**Wang Ke (王可) and Li Can (李灿) — Fudan University**

**Zenodo DOI:** `10.5281/zenodo.23038546`

This packet records a computer-assisted exact certificate implying

` s(11) > 3875000000 / 999999999 = 3.875000003875000003875... `

for eleven independently rotatable unit squares packed into a square.

The improvement over `31/8` is exact:

`3875000000/999999999 - 31/8 = 31/7999999992 > 0`.

## Publication status

As checked on 29 September 2026, the public Squares Project still listed Kleddamag's `s(11) > 31/8` certificate as the strongest verified lower bound. No stronger registered lower bound was located in that dated public check. The mathematical claim in this release is the exact theorem and certificate stated below; users are encouraged to reproduce the full verification independently.

## Headline certificate data

- `L = 191/50`
- `A' = 190999999809/193750000000`
- `lambda = 999999999/1000000000`
- `L/A' = 3875000000/999999999`
- rows: `12028` (`0..12027`)
- minimum charge: `1000047559` units of `10^-9`
- budget: `11000095024` units of `10^-9`
- counting surplus: `428125` units of `10^-9`
- source certificate SHA-256: `57e9927da5c13f42dd8bcbf8f08c84363635fece626657ee63a810c61cd44458`
- improved certificate SHA-256: `31e10ceb8368cc858e61f45ce7cfee783e8d0c7910893559164810f45439cc34`

Recorded complete replays return the one-bin histogram:

`{1000047559: 12028}`

with zero bad rows in the recorded independent replay.

## What changed

Only thirteen threshold-charge orbit weights are increased:

`3:+1, 27:+4, 43:+3, 51:+4384, 52:+7, 130:+34344, 131:+1, 174:+3776, 206:+5, 207:+1, 218:+7, 232:+5, 259:+1`.

Then `A` and every row-specific `B` are multiplied by the common exact factor `999999999/1000000000`.

## Reproduce

Recommended environment:

```bash
python3 -m venv .venv
. .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
```

First run the fast integrity and smoke checks:

```bash
python verify.py --mode integrity
python verify.py --mode quick
```

A successful quick run prints:

- `PASS_STATIC_INTEGRITY`
- `PASS_QUICK_SMOKE`
- primary row 0 = `1000047559`
- independent row 0 = `1000047559`

For a fresh two-implementation replay of all 12,028 rows:

```bash
python verify.py --mode full --jobs 5
```

The full mode runs the Kleddamag-derived exact polygon/event-cell sweep and the separately implemented Fraction/integer/block-sweep verifier, then requires identical one-bin histograms, minima, budget and surplus. Allow substantial runtime; the previously recorded independent full replay took about 659.6 seconds on its recorded machine.

### Packaging audit performed on 29 September 2026

During assembly of this release, we freshly reran:

1. SHA-256 verification of both frozen certificates;
2. an independent structural comparison showing exactly the intended 13 charge-orbit weight changes and the common scaling of all 12,028 row-specific `B` values;
3. recomputation of the feature budgets from certificate structure;
4. exact ratio and surplus arithmetic;
5. a portable row-0 smoke test through both bundled verifier implementations;
6. a fresh primary exact replay of rows **0–3006**; and
7. a fresh primary exact replay of rows **3007–6013**; and
8. a fresh primary exact replay of rows **6014–9020**; and
9. a fresh primary exact replay of rows **9021–12027**.

Thus, **12,028 / 12,028** primary rows have been freshly rerun during this staged packaging process, all with exact minimum `1000047559`. The merged receipt is `evidence/fresh_replay/primary_full_fresh_12028.json`. The earlier complete primary and independent full-replay receipts remain preserved in `evidence/` for comparison. `--mode full` is supplied so a third party can independently regenerate both full replays from the packet.

## Directory map

- `paper/` — Word, LaTeX and PDF preprint, authors Wang Ke (王可) and Li Can (李灿), Fudan University.
- `certificate/` — frozen source and improved certificates.
- `evidence/` — fixed-parameter, primary full-replay and independent full-replay receipts.
- `verifier/primary_kleddamag/` — portable MIT-licensed Kleddamag-derived primary Python sweep.
- `verifier/independent/` — independent exact verifier and full-replay driver.
- `verify.py` — release-level integrity/smoke/full entry point.
- `SOURCE_ATTRIBUTION.md` — mathematical and data lineage.
- `THIRD_PARTY_NOTICES.md` — licence obligations for bundled upstream material.
- `LICENSE_STATUS.md` — file-by-file licence scope for this mixed-license archive.
- `LICENSES/` — Wang Ke/Li Can CC BY 4.0 notice and MIT licence text.
- `EXTERNAL_REVIEW_REQUEST.md` — ready-to-send verification request.

## Attribution

This is a derivative continuation of Kleddamag's September 2026 certificate, which itself builds on Joshua Levy and collaborators' Squares Project threshold-certificate framework/data. See `SOURCE_ATTRIBUTION.md` and `THIRD_PARTY_NOTICES.md` before redistribution.

No claim is made to Walter Trump's upper-bound construction, to the source `31/8` certificate, or to the general threshold-counting method.

## Licence summary

This is a mixed-license archive. Wang Ke / Li Can paper and original release documentation are CC BY 4.0; Wang Ke / Li Can original verifier software is MIT; bundled Kleddamag-derived code retains its upstream MIT notice; certificate/data lineage retains the applicable upstream attribution described in `THIRD_PARTY_NOTICES.md`. See `LICENSE_STATUS.md` for the exact file-level scope.
