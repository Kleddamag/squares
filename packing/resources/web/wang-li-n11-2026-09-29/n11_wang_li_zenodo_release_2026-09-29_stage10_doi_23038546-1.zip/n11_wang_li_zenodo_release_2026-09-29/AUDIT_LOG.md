# Release audit log — 29 September 2026

## Fresh checks performed during packaging

- Reserved Zenodo DOI written into final release metadata and paper: `10.5281/zenodo.23038546`.

- Source certificate SHA-256: PASS.
- Improved certificate SHA-256: PASS.
- Row count: 12,028 in source and improved certificates.
- `A' = lambda A`: PASS exactly.
- Every one of the 12,028 row-specific `B' = lambda B`: PASS exactly.
- No changes to point orbits: PASS.
- Charge-orbit changes: exactly the intended 13 deltas and no others.
- Source budget recomputed from point/threshold structure: `10999479944`.
- Improved budget recomputed from point/threshold structure: `11000095024`.
- Exact bound: `3875000000/999999999`.
- Exact improvement over `31/8`: `31/7999999992`.
- Counting surplus: `11*1000047559 - 11000095024 = 428125`.
- Frozen receipts internally consistent with the headline data: PASS.
- Portable primary verifier row-0 smoke: `1000047559`.
- Portable independent verifier row-0 smoke: `1000047559`.
- DOCX rendered and visually inspected page-by-page after reserved-DOI insertion: PASS (5 pages).
- LaTeX PDF regenerated from source and visually inspected page-by-page after reserved-DOI insertion: PASS (6 pages).

## Fresh staged replay status

- Q1 fresh primary exact replay: rows `0–3006`, **3007/3007 PASS**, one-bin histogram `{1000047559: 3007}`.
- Q2 fresh primary exact replay: rows `3007–6013`, **3007/3007 PASS**, one-bin histogram `{1000047559: 3007}`.
- Q3 fresh primary exact replay: rows `6014–9020`, **3007/3007 PASS**, one-bin histogram `{1000047559: 3007}`.
- Q4 fresh primary exact replay: rows `9021–12027`, **3007/3007 PASS**, one-bin histogram `{1000047559: 3007}`.
- Cumulative fresh primary coverage in this staged packaging process: **12028 / 12028 rows**.
- Merged fresh primary receipt: `evidence/fresh_replay/primary_full_fresh_12028.json`, one-bin histogram `{1000047559: 12028}`.

The four quarter receipts cover every angular row exactly once, with no gaps or overlaps. The package also preserves the earlier completed 12,028-row primary and independent full-replay receipts.
