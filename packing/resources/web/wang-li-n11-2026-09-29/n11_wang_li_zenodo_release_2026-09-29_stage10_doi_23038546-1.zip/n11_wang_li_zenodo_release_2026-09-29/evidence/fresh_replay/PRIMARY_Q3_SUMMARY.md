# Primary exact replay — Q3

- Scope: rows **6014–9020** inclusive.
- Rows checked: **3007 / 12028**.
- Certificate SHA-256: `31e10ceb8368cc858e61f45ce7cfee783e8d0c7910893559164810f45439cc34`.
- Result: **PASS**.
- Minimum row charge: **1000047559**.
- Maximum row charge: **1000047559**.
- Histogram: `{1000047559: 3007}`.
- Counting surplus using the Q3 minimum: **428125** units.

This receipt records a fresh exact replay of the third quarter only. Rows 9021–12027 are not part of this stage.
