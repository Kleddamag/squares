#!/usr/bin/env python3
from __future__ import annotations
import json, math, hashlib, random, bisect
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CERT = ROOT / 'certificate' / 'global-certificate-original.json'
RECEIPT = ROOT / 'evidence' / 'reweighted_fullscan_receipt.json'

# Deliberately independent implementation: does not import diagnose_kleddamag_row.py,
# fastsweep.py, or any earlier scan code.

class SegTree:
    def __init__(self, n):
        size=1
        while size<n: size*=2
        self.n=n; self.size=size
        self.mn=[0]*(2*size); self.lazy=[0]*(2*size)
    def _add(self,p,v):
        self.mn[p]+=v; self.lazy[p]+=v
    def _push(self,p):
        z=self.lazy[p]
        if z:
            self._add(p*2,z); self._add(p*2+1,z); self.lazy[p]=0
    def add(self,l,r,v,p=1,a=0,b=None):
        if b is None: b=self.size
        if r<=a or b<=l: return
        if l<=a and b<=r:
            self._add(p,v); return
        self._push(p); m=(a+b)//2
        self.add(l,r,v,p*2,a,m); self.add(l,r,v,p*2+1,m,b)
        self.mn[p]=min(self.mn[p*2],self.mn[p*2+1])
    def qmin_arg(self,l,r,p=1,a=0,b=None):
        if b is None: b=self.size
        if r<=a or b<=l: return (10**30,-1)
        if b-a==1:
            return (self.mn[p],a) if l<=a<r and a<self.n else (10**30,-1)
        if l<=a and b<=r and self.mn[p] < 10**30:
            # Need an argmin, descend only along a minimum child.
            self._push(p); m=(a+b)//2
            left_ok=not (m<=l or r<=a)
            right_ok=not (b<=l or r<=m)
            candidates=[]
            if left_ok: candidates.append((self._range_min(l,r,p*2,a,m),0))
            if right_ok: candidates.append((self._range_min(l,r,p*2+1,m,b),1))
            val,side=min(candidates)
            return self._arg_for_value(l,r,val,p*2+side,a if side==0 else m,m if side==0 else b)
        self._push(p); m=(a+b)//2
        x=self.qmin_arg(l,r,p*2,a,m); y=self.qmin_arg(l,r,p*2+1,m,b)
        return x if x[0]<=y[0] else y
    def _range_min(self,l,r,p,a,b):
        if r<=a or b<=l: return 10**30
        if l<=a and b<=r: return self.mn[p]
        self._push(p); m=(a+b)//2
        return min(self._range_min(l,r,p*2,a,m), self._range_min(l,r,p*2+1,m,b))
    def _arg_for_value(self,l,r,val,p,a,b):
        if b-a==1:
            return (self.mn[p],a) if a<self.n and l<=a<r else (10**30,-1)
        self._push(p); m=(a+b)//2
        lv=self._range_min(l,r,p*2,a,m)
        if lv==val:
            return self._arg_for_value(l,r,val,p*2,a,m)
        return self._arg_for_value(l,r,val,p*2+1,m,b)

def trig(t):
    return (1-t*t)/(1+t*t), (2*t)/(1+t*t)

def d4_orbit(x,y,LD):
    return sorted({(a,b) for u,v in ((x,y),(y,x)) for a in (u,LD-u) for b in (v,LD-v)})

def expand_positive_and_signed(c):
    D=int(c['coordinate_denominator']); L=Q(c['L']); LD=int(L*D)
    pts=[]; pweights=[]
    for x,y,w in c['point_orbits']:
        orb=d4_orbit(x,y,LD); pts.extend(orb); pweights.extend([int(w)]*len(orb))
    assert len(pts)==len(set(pts))
    signed=[] # (indices tuple, coefficient)
    budget=sum(pweights)
    for atom in c['charge_orbits']:
        groups=atom['sets']; r=int(atom['threshold']); w=int(atom['weight']); n=len(groups[0])
        budget += len(groups)*(n//r)*w
        for inds in groups:
            inds=tuple(inds)
            for j in range(r,n+1):
                coef=(((-1)**(j-r))*math.comb(j-1,r-1)*w)
                for sub in combinations(inds,j): signed.append((sub,coef))
    return pts,pweights,signed,budget,D

def row_params(c,ri):
    L=Q(c['L']); A=Q(c['A']); a,b,t,B=map(Q,c['entries'][ri])
    ct,st=trig(t)
    fs=[]; gs=[]
    for u in (a,b):
        cu,su=trig(u); fs.append(cu+su); gs.append(ct*cu+st*su+abs(ct*su-st*cu))
    assert A-B*max(gs)>0
    r=A*min(fs)/2; H=L/2-r
    return t,B,H

def build_row(c,pts,pweights,signed,D,ri):
    t,B,H=row_params(c,ri)
    p=t.numerator; q=t.denominator
    C=q*q-p*p; S=2*p*q; R=q*q+p*p
    L=Q(c['L']); LD=int(L*D)
    scale=math.lcm(2*D,(B/2).denominator,H.denominator)
    fac=scale//(2*D); h=int(H*scale); half=int(B*scale/2)*R
    uv=[(C*(2*x-LD)*fac+S*(2*y-LD)*fac,
         -S*(2*x-LD)*fac+C*(2*y-LD)*fac) for x,y in pts]
    rect={}
    def ins(ids,w):
        if not w:return
        xs=[uv[i][0] for i in ids]; ys=[uv[i][1] for i in ids]
        z=(max(xs)-half,min(xs)+half,max(ys)-half,min(ys)+half)
        if z[0]<z[1] and z[2]<z[3]: rect[z]=rect.get(z,0)+w
    for i,w in enumerate(pweights): ins((i,),w)
    for ids,w in signed: ins(ids,w)
    rect={r:w for r,w in rect.items() if w}
    # Legal center polygon in same unnormalised rotated coordinates.
    poly=[(C*x+S*y,-S*x+C*y) for x,y in ((-h,-h),(h,-h),(h,h),(-h,h))]
    xe=sorted({x for x,y in poly}|{z for r in rect for z in r[:2]})
    ye=sorted({y for x,y in poly}|{z for r in rect for z in r[2:]})
    xid={v:i for i,v in enumerate(xe)}; yid={v:i for i,v in enumerate(ye)}
    events=[[] for _ in xe]
    for rr,w in rect.items():
        yl=yid[rr[2]]; yh=yid[rr[3]]
        events[xid[rr[0]]].append((yl,yh,w)); events[xid[rr[1]]].append((yl,yh,-w))
    # precompute nonvertical polygon edge line y=(m*x+n)/d
    edges=[]
    for k in range(4):
        x1,y1=poly[k]; x2,y2=poly[(k+1)%4]
        if x1==x2: continue
        if x2<x1: x1,y1,x2,y2=x2,y2,x1,y1
        edges.append((x1,x2,y2-y1,y1*(x2-x1)-x1*(y2-y1),x2-x1))
    return uv,half,poly,xe,ye,events,edges,scale,C,S,R

def legal_y_indices(aa,bb,ye,edges):
    vals=[]
    for x1,x2,m,n,d in edges:
        if x1<=aa and bb<=x2:
            vals.append(Q(m*aa+n,d)); vals.append(Q(m*bb+n,d))
    if len(vals)!=4: return None
    low=min(vals); high=max(vals)
    lo=bisect.bisect_right(ye,low)-1
    hi=bisect.bisect_left(ye,high)
    if lo<0:lo=0
    if hi>len(ye)-1:hi=len(ye)-1
    return (lo,hi) if lo<hi else None

def row_min(c,pts,pweights,signed,D,ri,need_arg=False):
    uv,half,poly,xe,ye,events,edges,scale,C,S,R=build_row(c,pts,pweights,signed,D,ri)
    st=SegTree(len(ye)-1); best=10**30; arg=None
    for k in range(len(xe)-1):
        for yl,yh,w in events[k]: st.add(yl,yh,w)
        rg=legal_y_indices(xe[k],xe[k+1],ye,edges)
        if rg:
            z,j=st.qmin_arg(*rg)
            if z<best: best=z; arg=(k,j)
    if need_arg: return best,arg,(uv,half,poly,xe,ye,scale,C,S,R)
    return best

def _clip_poly(poly, axis, bound, keep_ge):
    out=[]
    if not poly: return out
    def val(pt): return pt[axis]
    def inside(pt): return val(pt)>=bound if keep_ge else val(pt)<=bound
    prev=poly[-1]; pin=inside(prev)
    for cur in poly:
        cin=inside(cur)
        if cin != pin:
            # segment prev->cur intersects coordinate=bound
            d=cur[axis]-prev[axis]
            assert d != 0
            t=(bound-prev[axis])/d
            inter=(prev[0]+t*(cur[0]-prev[0]), prev[1]+t*(cur[1]-prev[1]))
            out.append(inter)
        if cin: out.append(cur)
        prev, pin=cur, cin
    return out

def interior_rep(meta,arg):
    uv,half,poly,xe,ye,scale,C,S,R=meta; k,j=arg
    x0,x1=Q(xe[k]),Q(xe[k+1]); y0,y1=Q(ye[j]),Q(ye[j+1])
    pp=[(Q(x),Q(y)) for x,y in poly]
    pp=_clip_poly(pp,0,x0,True); pp=_clip_poly(pp,0,x1,False)
    pp=_clip_poly(pp,1,y0,True); pp=_clip_poly(pp,1,y1,False)
    assert len(pp)>=3
    # ensure positive area
    area=sum(pp[i][0]*pp[(i+1)%len(pp)][1]-pp[(i+1)%len(pp)][0]*pp[i][1] for i in range(len(pp)))
    assert area != 0
    U=sum(x for x,y in pp)/len(pp); V=sum(y for x,y in pp)/len(pp)
    assert x0 < U < x1 and y0 < V < y1
    return U,V

def direct_positive(c,pts,pweights,ri,U,V):
    # independently rebuild only site coordinates for row and evaluate nonnegative features.
    t,B,H=row_params(c,ri); p=t.numerator; q=t.denominator
    C=q*q-p*p; S=2*p*q; R=q*q+p*p; D=int(c['coordinate_denominator']); L=Q(c['L']); LD=int(L*D)
    scale=math.lcm(2*D,(B/2).denominator,H.denominator); fac=scale//(2*D); half=int(B*scale/2)*R
    held=[]
    for x,y in pts:
        ux=C*(2*x-LD)*fac+S*(2*y-LD)*fac; vy=-S*(2*x-LD)*fac+C*(2*y-LD)*fac
        held.append(abs(Q(ux)-U)<half and abs(Q(vy)-V)<half)
    total=sum(w for w,h in zip(pweights,held) if h)
    for atom in c['charge_orbits']:
        r=int(atom['threshold']); w=int(atom['weight'])
        for g in atom['sets']:
            if sum(held[i] for i in g)>=r: total+=w
    return total

def apply_deltas(base,receipt):
    # deep enough JSON roundtrip copy
    c=json.loads(json.dumps(base))
    for k,d in receipt['weight_deltas'].items(): c['charge_orbits'][int(k)]['weight']+=int(d)
    return c

def main():
    raw=CERT.read_bytes(); sha=hashlib.sha256(raw).hexdigest(); base=json.loads(raw); rec=json.loads(RECEIPT.read_text())
    assert sha==rec['source_sha256']
    mod=apply_deltas(base,rec)
    # Build each expansion independently because coefficients depend on weights.
    bp,bpw,bsigned,bbudget,D=expand_positive_and_signed(base)
    mp,mpw,msigned,mbudget,D2=expand_positive_and_signed(mod)
    assert bp==mp and D==D2
    assert bbudget==base['budget_units']==rec['source_budget_units']
    assert mbudget==rec['certified_budget_units']
    assert 11*rec['certified_minimum_units']-mbudget==rec['counting_surplus_units']

    known={0:1000047518,3985:1000019046,8844:999970079,9281:1000031217,9740:1000010082,11962:999962528,12027:1000047518}
    original={}
    for r,expect in known.items():
        got=row_min(base,bp,bpw,bsigned,D,r)
        assert got==expect,(r,got,expect)
        original[r]=got

    # deterministic stratified/random sample across entire catalogue
    sample={0,1,499,1000,1999,3000,3395,3396,3985,5000,6000,6791,6792,7000,7792,8844,9281,9740,10000,11000,11962,12027}
    rng=random.Random(20260929)
    sample.update(rng.sample(range(12028),10))
    sample=sorted(sample)
    rew={}
    reps={}
    rep_rows={0,3396,6792,8844,9281,11962,12027}
    for r in sample:
        if r in rep_rows:
            got,arg,meta=row_min(mod,mp,mpw,msigned,D,r,True)
            U,V=interior_rep(meta,arg)
            direct=direct_positive(mod,mp,mpw,r,U,V)
            assert direct==got,(r,direct,got)
            reps[r]={'sweep':got,'direct_positive':direct,'cell':[arg[0],arg[1]]}
        else:
            got=row_min(mod,mp,mpw,msigned,D,r)
        assert got==rec['certified_minimum_units'],(r,got)
        rew[r]=got

    out={
      'status':'PASS_INDEPENDENT_AUDIT',
      'implementation':'standalone Fraction + lazy segment-tree sweep; imports no prior verifier modules',
      'source_sha256':sha,
      'source_budget_recomputed':bbudget,
      'reweighted_budget_recomputed':mbudget,
      'receipt_budget':rec['certified_budget_units'],
      'receipt_minimum':rec['certified_minimum_units'],
      'receipt_surplus_recomputed':11*rec['certified_minimum_units']-mbudget,
      'original_known_rows_verified':original,
      'reweighted_sample_count':len(sample),
      'reweighted_sample_rows':sample,
      'reweighted_distinct_minima':sorted(set(rew.values())),
      'direct_positive_crosschecks':reps,
    }
    p=ROOT / 'evidence' / 'recomputed-independent-audit-receipt.json'; p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(out,indent=2,sort_keys=True))

if __name__=='__main__': main()
