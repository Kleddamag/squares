# Authors

**王可 (Wang Ke)** — Fudan University  
**李灿 (Li Can)** — Fudan University

For English-language citation and indexing, this release uses the romanized names **Wang Ke** and **Li Can**. The corresponding Chinese names are **王可** and **李灿**.

## Contribution scope

This release claims authorship only for the continuation represented here: the 13-orbit reweighting, the exact common rational parent/core shrink, the derived certificate, and the verification/release work for the improved ratio.

It does **not** claim authorship of Kleddamag's source `s(11) > 31/8` certificate, Joshua Levy and collaborators' Squares Project framework/data, Walter Trump's upper-bound construction, or the general parent-core/threshold-counting method.
