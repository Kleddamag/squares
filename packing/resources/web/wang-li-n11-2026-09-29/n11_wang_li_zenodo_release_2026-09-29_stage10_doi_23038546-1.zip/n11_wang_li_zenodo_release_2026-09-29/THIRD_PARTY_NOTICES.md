# Third-party notices and licence scope

This release contains material derived from two public research/code sources.
The notices below are preserved separately from the Wang Ke / Li Can licences.

## Kleddamag source code

The files in `verifier/primary_kleddamag/` are reproduced/adapted from
Kleddamag's public repository:

https://github.com/Kleddamag/11-squares-certified-bound

The upstream repository is distributed under the MIT License. Its copyright
notice and permission text are preserved verbatim in:

`verifier/primary_kleddamag/LICENSE_KLEDDAMAG_MIT.txt`

## Squares Project certificate/data lineage

Kleddamag's source certificate was developed from Joshua Levy's Squares Project
threshold-certificate work. The Squares Project licence states that its code is
MIT-licensed and that its documentation, research records, data, and figures
are licensed under **Creative Commons Attribution 4.0 International (CC BY
4.0)**, with attribution to:

**Joshua Levy, the squares project (https://github.com/jlevy/squares)**

Accordingly this release preserves that attribution for the certificate/data
lineage. In particular:

- `certificate/global-certificate-original.json` is the frozen source
  certificate used here;
- `certificate/improved-global-certificate.json` is an adapted certificate in
  which Wang Ke and Li Can change thirteen threshold-charge orbit weights and
  apply the stated common exact rational scaling.

The adapted file is explicitly identified as modified. This release does not
claim that Joshua Levy, the Squares Project contributors, or Kleddamag endorse
this work or are coauthors of it.

CC BY 4.0 licence URI:
https://creativecommons.org/licenses/by/4.0/

This release does not purport to relicense upstream material beyond rights
granted by the applicable upstream licences.
