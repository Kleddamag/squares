# Fresh primary replay — quarter 1

- Scope: rows **0–3006** inclusive (**3007 / 12028** rows).
- Status: **PASS**.
- Improved certificate SHA-256: `31e10ceb8368cc858e61f45ce7cfee783e8d0c7910893559164810f45439cc34`.
- Exact minimum over this quarter: **1000047559** units.
- Exact maximum over this quarter: **1000047559** units.
- Histogram: `{'1000047559': 3007}`.
- Budget units: **11000095024**.
- Counting surplus using the quarter minimum: **428125** units.
- Exact bound encoded by the certificate: **3875000000/999999999**.

This staged package intentionally records only the first quarter of the fresh primary replay. It does **not** present this Q1 artifact as a new complete 12,028-row fresh replay. The release still contains the earlier full-replay receipts that were already part of v1.0.0 preparation.
