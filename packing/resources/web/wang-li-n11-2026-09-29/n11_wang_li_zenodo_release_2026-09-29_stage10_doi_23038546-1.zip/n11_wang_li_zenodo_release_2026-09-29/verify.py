#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, math, os, subprocess, sys
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'certificate'/'global-certificate-original.json'
IMPROVED=ROOT/'certificate'/'improved-global-certificate.json'
REC_REW=ROOT/'evidence'/'reweighted_fullscan_receipt.json'
REC_PRIMARY=ROOT/'evidence'/'scaledA_full12028_receipt.json'
REC_INDEP=ROOT/'evidence'/'independent-full-replay-receipt.json'
EXPECTED_SOURCE='57e9927da5c13f42dd8bcbf8f08c84363635fece626657ee63a810c61cd44458'
EXPECTED_IMPROVED='31e10ceb8368cc858e61f45ce7cfee783e8d0c7910893559164810f45439cc34'
TARGET=1000047559
BUDGET=11000095024
LAM=F(999999999,1000000000)
DELTAS={3:1,27:4,43:3,51:4384,52:7,130:34344,131:1,174:3776,206:5,207:1,218:7,232:5,259:1}

def sha(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest()

def orbit_size(x,y,LD):
    return len({(a,b) for u,v in ((x,y),(y,x)) for a in (u,LD-u) for b in (v,LD-v)})

def recompute_budget(c):
    D=int(c['coordinate_denominator']); L=F(c['L']); LD=int(L*D)
    total=sum(orbit_size(x,y,LD)*int(w) for x,y,w in c['point_orbits'])
    for atom in c['charge_orbits']:
        groups=atom['sets']; r=int(atom['threshold']); w=int(atom['weight']); n=len(groups[0])
        assert groups and all(len(g)==n for g in groups)
        total += len(groups)*(n//r)*w
    return total

def integrity():
    assert sha(SOURCE)==EXPECTED_SOURCE
    assert sha(IMPROVED)==EXPECTED_IMPROVED
    src=json.loads(SOURCE.read_text()); imp=json.loads(IMPROVED.read_text()); rew=json.loads(REC_REW.read_text()); pr=json.loads(REC_PRIMARY.read_text()); ir=json.loads(REC_INDEP.read_text())
    assert len(src['entries'])==len(imp['entries'])==12028
    assert F(imp['A'])==F(src['A'])*LAM
    assert F(imp['L'])/F(imp['A'])==F(3875000000,999999999)
    assert F(3875000000,999999999)-F(31,8)==F(31,7999999992)>0
    assert src['point_orbits']==imp['point_orbits']
    changed={}
    for i,(a,b) in enumerate(zip(src['charge_orbits'],imp['charge_orbits'])):
        aa=dict(a); bb=dict(b)
        if aa!=bb:
            d=bb['weight']-aa['weight']; changed[i]=d
            aa['weight']=bb['weight']; assert aa==bb
    assert changed==DELTAS
    for a,b in zip(src['entries'],imp['entries']):
        assert a[:3]==b[:3]
        assert F(b[3])==F(a[3])*LAM
    assert recompute_budget(src)==src['budget_units']==10999479944
    assert recompute_budget(imp)==imp['budget_units']==BUDGET
    assert imp['minimum_units']==TARGET
    assert 11*TARGET-BUDGET==428125
    assert rew['certified_minimum_units']==TARGET and rew['certified_budget_units']==BUDGET and rew['counting_surplus_units']==428125
    assert pr['minimum_units']==TARGET and pr['budget_units']==BUDGET and pr['counting_surplus_units']==428125 and pr['row_count']==12028
    assert ir['status']=='PASS_INDEPENDENT_FULL_REPLAY' and ir['bad_count']==0 and ir['row_count']==12028
    assert ir['histogram']=={str(TARGET):12028} and ir['counting_surplus_units']==428125
    out={
      'status':'PASS_STATIC_INTEGRITY', 'source_sha256':EXPECTED_SOURCE, 'improved_sha256':EXPECTED_IMPROVED,
      'rows':12028, 'changed_orbits':sorted(changed), 'minimum_units':TARGET, 'budget_units':BUDGET,
      'counting_surplus_units':428125, 'bound':'3875000000/999999999', 'improvement_over_31_8':'31/7999999992'
    }
    print(json.dumps(out,indent=2))
    return out

def smoke():
    integrity()
    # Primary checker: exact validation + row 0.
    code="""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path('verifier/primary_kleddamag').resolve()))
from exact_mixed import validate,geometry,accumulate
c=json.load(open('certificate/improved-global-certificate.json')); data,jobs,margin=validate(c); ar=geometry(*data,*jobs[0]); z,cells,win=accumulate(*ar); print(z); assert int(z)==1000047559
"""
    subprocess.run([sys.executable,'-c',code],cwd=ROOT,check=True)
    # Independent checker: compile + row 0.
    code2="""
import sys
from pathlib import Path
sys.path.insert(0,str(Path('verifier/independent').resolve()))
import independent_scaled_fast as v
z=v.row_min_fast(0); print(z); assert z==1000047559
"""
    subprocess.run([sys.executable,'-c',code2],cwd=ROOT,check=True)
    print(json.dumps({'status':'PASS_QUICK_SMOKE','primary_row':0,'independent_row':0,'minimum_units':TARGET},indent=2))

def full(jobs):
    integrity()
    out=ROOT/'evidence'/'fresh-full-replay'; out.mkdir(parents=True,exist_ok=True)
    primary=out/'primary.json'; indep=out/'independent.json'
    subprocess.run([sys.executable,str(ROOT/'verifier/primary_kleddamag/replay_parallel.py'),str(IMPROVED),'--output',str(primary),'--jobs',str(jobs)],check=True,cwd=ROOT)
    subprocess.run([sys.executable,str(ROOT/'verifier/independent/run_independent_full.py'),'--jobs',str(jobs),'--output',str(indep)],check=True,cwd=ROOT)
    a=json.loads(primary.read_text()); b=json.loads(indep.read_text())
    assert a['status']=='PASS_FULL_EXACT_PYTHON_REPLAY' and b['status']=='PASS_INDEPENDENT_FULL_REPLAY'
    assert a['certificate_sha256']==b['improved_certificate_sha256']==EXPECTED_IMPROVED
    assert a['intervals']==b['row_count']==12028
    assert a['minimum_units']==b['minimum_units']==TARGET
    assert a['budget_units']==b['budget_units']==BUDGET
    assert a['counting_surplus_units']==b['counting_surplus_units']==428125
    assert a['histogram']==b['histogram']=={str(TARGET):12028}
    result={'status':'PASS_FRESH_TWO_IMPLEMENTATION_FULL_REPLAY','certificate_sha256':EXPECTED_IMPROVED,'rows':12028,'histogram':{str(TARGET):12028},'surplus_units':428125}
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

def main():
    ap=argparse.ArgumentParser(description='Verify the Wang-Li s(11) exact lower-bound release.')
    ap.add_argument('--mode',choices=['integrity','quick','full'],default='quick')
    ap.add_argument('--jobs',type=int,default=max(1,min(5,os.cpu_count() or 1)))
    a=ap.parse_args()
    if a.mode=='integrity': integrity()
    elif a.mode=='quick': smoke()
    else: full(a.jobs)
if __name__=='__main__': main()
