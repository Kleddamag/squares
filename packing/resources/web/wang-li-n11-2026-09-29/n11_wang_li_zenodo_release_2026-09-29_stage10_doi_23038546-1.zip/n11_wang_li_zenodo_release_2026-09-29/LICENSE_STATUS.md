# Licence scope for this mixed-license release

This Zenodo package deliberately uses **more than one licence**. No single
licence is intended to override the file-specific scope below.

## 1. Wang Ke / Li Can prose, paper, metadata, and research-record material — CC BY 4.0

Unless a file is listed in another section below, original material authored by
**Wang Ke (王可)** and **Li Can (李灿)** in this release is licensed under
**Creative Commons Attribution 4.0 International (CC BY 4.0)**. This includes,
in particular:

- `paper/n11_lower_bound_wang_li.{pdf,docx,tex}`;
- top-level release documentation and metadata written for this package;
- release/audit records in `evidence/` to the extent they contain original
  expression or compilation by Wang Ke and Li Can.

Licence notice: `LICENSES/WANG_LI_CC_BY_4.0_NOTICE.txt`
Licence URI: https://creativecommons.org/licenses/by/4.0/

## 2. Wang Ke / Li Can original software — MIT

The release-level wrapper and independently written verifier code are licensed
under the **MIT License**:

- `verify.py`;
- `verifier/independent/*.py`;
- `requirements.txt` to the extent copyright applies.

MIT text: `LICENSES/WANG_LI_MIT.txt`

## 3. Kleddamag-derived verifier code — upstream MIT

Files in `verifier/primary_kleddamag/` are reproduced/adapted from Kleddamag's
MIT-licensed repository. They remain under the upstream MIT terms preserved in:

`verifier/primary_kleddamag/LICENSE_KLEDDAMAG_MIT.txt`

The Wang Ke / Li Can MIT notice does **not** replace the upstream copyright and
licence notice for those files.

## 4. Certificates and upstream-derived data

`certificate/global-certificate-original.json` is retained as source material
with its upstream attribution. `certificate/improved-global-certificate.json`
is an adapted certificate and retains the upstream attribution while recording
Wang Ke / Li Can's modifications. The relevant CC BY 4.0 attribution chain is
described in `THIRD_PARTY_NOTICES.md` and `SOURCE_ATTRIBUTION.md`.

Nothing in this package purports to relicense third-party material beyond the
permissions granted by its applicable upstream licence.

## 5. Zenodo licence fields

Because Zenodo supports mixed-license uploads, select **both** of the following
licences for the record:

- `Creative Commons Attribution 4.0 International (CC-BY-4.0)`;
- `MIT License (MIT)`.

The file-level scope in this document controls how those two licences apply
inside the archive.
